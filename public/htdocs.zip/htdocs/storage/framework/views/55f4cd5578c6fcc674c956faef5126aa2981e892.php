<footer class="footer">
    <div class="container-fluid">
        <ul class="nav">
            
        </ul>
        <div class="copyright">
            &copy; <?php echo e(now()->year); ?>  ULOPS
        </div>
    </div>
</footer>
<?php /**PATH /home/bitnami/htdocs/resources/views/layouts/footer.blade.php ENDPATH**/ ?>