<footer class="footer">
    <div class="container-fluid">
        <ul class="nav">
            
        </ul>
        <div class="copyright">
            &copy; {{ now()->year }}  ULOPS
        </div>
    </div>
</footer>
